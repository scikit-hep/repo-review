"""
Copyright (c) 2022 Henry Schreiner. All rights reserved.

scikit-hep-repo-review: Review repos for compliance to the Scikit-HEP developer guidelines
"""


from __future__ import annotations

__version__ = "0.2.0"

__all__ = ("__version__",)
